package infinite.oyo;

public enum Status {
	AVAILABLE,BOOKED
}
